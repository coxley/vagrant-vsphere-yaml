# StdMod shared module

This module contains functions and resources used by StdMod based modules generated from https://github.com/stdmod/puppet-skeletons.

The intention is to try to move upstream (on PuppetLabs' stdlib) as many resources as possible and keep here only the ones that are not (yet?) being merged into StdLib.

StdMod is a community effort to standardized modules naming conventions, open to everybody.
This module is published on the Forge under the example42 account because it was not possible to create a stdmod user.
